import sys
import nmap

range = "203.28.8.0/24"

# def ip_scan(ip_range):
#     try:
#         # Find active hosts
#         nm = nmap.PortScanner()

#         # Adding -n disables DNS resolution which makes it faster
#         # Ip range scan uses -sn to disable port scan
#         nm.scan(hosts=ip_range, arguments='-n -sn', callback=callback_result, timeout=5)
#         hosts_list = [(x, nm[x]['status']['state']) for x in nm.all_hosts()]

#         # Sort hosts by ip
#         hosts_list = sorted(hosts_list, key=lambda x: [int(i) for i in x[0].split('.')])

#         # Print active hosts
#         # for host, status in hosts_list:
#         #     print(f'{host} -> LIVE')
#         for host, status in hosts_list:
#             print(f'{host}:{status}')
#     except KeyboardInterrupt:
#         print("IP scan: Interrupted")
#         sys.exit(0)


# if __name__ == '__main__':
#     # Get args or show prompt to get ip range
#     # if len(sys.argv) > 1:
#     #     ip_range = sys.argv[1]
#     # else:
#     #     ip_range = input("ip_scan > ")

#     ip_scan(range)

import sys
import nmap
import socket
import time
def ping(host):
    # Check if host is valid
    try:
        ip = socket.gethostbyname(host)
        print(f"Pinging {host} ({ip})")
        nm = nmap.PortScanner()

        # Ping host 4 times
        for i in range(4):
            # The switch -sn disables port scan and is used for ping hosts
            nm.scan(hosts=ip, arguments='-sn')
            hosts_list = [(x, nm[x]['status']['state']) for x in nm.all_hosts()]

            for host, status in hosts_list:
                print(f'Reply from {host} time={nm.scanstats()["elapsed"]}s')
            time.sleep(1)

    except socket.gaierror:
        print("Ping: Unknown host")
    except KeyboardInterrupt:
        print("Ping: Interrupted")
        sys.exit(0)

nma = nmap.PortScannerAsync()
def callback_result(host, scan_result):
    print ('------------------')
    print (host, scan_result['nmap']["scanstats"])
    print(ping(host))

nma.scan(hosts=range, arguments='-n -sn -sP', callback=callback_result)
while nma.still_scanning():
    # print("Waiting >>>")
    nma.wait(2)